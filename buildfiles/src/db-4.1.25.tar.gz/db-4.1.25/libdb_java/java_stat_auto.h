/* DO NOT EDIT: automatically built by dist/s_java. */
extern int __jv_fill_bt_stat(JNIEnv *jnienv, jclass cl, jobject jobj, struct __db_bt_stat *statp);
extern int __jv_fill_h_stat(JNIEnv *jnienv, jclass cl, jobject jobj, struct __db_h_stat *statp);
extern int __jv_fill_lock_stat(JNIEnv *jnienv, jclass cl, jobject jobj, struct __db_lock_stat *statp);
extern int __jv_fill_log_stat(JNIEnv *jnienv, jclass cl, jobject jobj, struct __db_log_stat *statp);
extern int __jv_fill_mpool_stat(JNIEnv *jnienv, jclass cl, jobject jobj, struct __db_mpool_stat *statp);
extern int __jv_fill_qam_stat(JNIEnv *jnienv, jclass cl, jobject jobj, struct __db_qam_stat *statp);
extern int __jv_fill_rep_stat(JNIEnv *jnienv, jclass cl, jobject jobj, struct __db_rep_stat *statp);
extern int __jv_fill_txn_stat(JNIEnv *jnienv, jclass cl, jobject jobj, struct __db_txn_stat *statp);
